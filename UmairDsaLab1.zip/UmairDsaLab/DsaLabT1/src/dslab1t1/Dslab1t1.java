/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dslab1t1;

/**
 *
 * @author ESHOP
 */
public class Dslab1t1 {

   
    public static void main(String[] args) {
      int num[]={5,15,25,35,45,55};
      
     for(int i=0;i<6;i++){
      System.out.println(" Element at index "+i +" : "+num[i]+" ");
     }
      
    }
    
}
