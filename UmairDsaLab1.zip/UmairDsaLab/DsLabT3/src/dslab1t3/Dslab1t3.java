/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dslab1t3;

/**
 *
 * @author ESHOP
 */
public class Dslab1t3 {

    
    public static void main(String[] args) {
        int[] arr={8,16,24,32,40};
        int deleteindex=2;
        for(int i=deleteindex;i<arr.length-1;i++){
        arr[i]=arr[i+1];
        }
        arr[arr.length-1]=0;
        
        for(int i=0;i<arr.length;i++){
            System.out.print(arr[i]+" ");}
        
    }
    
}
